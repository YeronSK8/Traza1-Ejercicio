package Clases;

import lombok.*;
import lombok.experimental.SuperBuilder;
import java.util.*;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true) // Con esto evitamos duplicados
@ToString(exclude = "sucursales")
@SuperBuilder
public class Empresa {
    @EqualsAndHashCode.Include
    private Long id;
    private String nombre;
    private String razonSocial;
    private Integer cuit;
    private String logo;
    private Long cuil;

    @Builder.Default
    private Set<Sucursal> sucursales = new HashSet<>();

    public void agregarSucursal(Sucursal sucursal) {
        sucursales.add(sucursal);
    }

    public Set<Sucursal> obtenerSucursales() {
        return Collections.unmodifiableSet(sucursales);
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Clases.Empresa{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", razonSocial='" + razonSocial + '\'' +
                ", cuit=" + cuit +
                ", cuil=" + cuil +
                '}';
    }
}