import Clases.*;
import Repositorios.InMemoryRepository;

import java.time.LocalTime;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Usamos directamente el repositorio genérico
        InMemoryRepository<Empresa> empresaRepo = new InMemoryRepository<>();

        // Crear país Argentina
        Pais argentina = Pais.builder().id(1L).nombre("Argentina").build();

        // Provincias
        Provincia buenosAires = Provincia.builder().id(2L).nombre("Buenos Aires").pais(argentina).build();
        Provincia cordoba = Provincia.builder().id(3L).nombre("Córdoba").pais(argentina).build();

        // Localidades
        Localidad caba = Localidad.builder().id(4L).nombre("CABA").provincia(buenosAires).build();
        Localidad laPlata = Localidad.builder().id(5L).nombre("La Plata").provincia(buenosAires).build();
        Localidad cordobaCapital = Localidad.builder().id(6L).nombre("Córdoba Capital").provincia(cordoba).build();
        Localidad carlosPaz = Localidad.builder().id(7L).nombre("Villa Carlos Paz").provincia(cordoba).build();

        // Domicilios
        Domicilio domicilioCaba = new Domicilio(1L, "Av. Corrientes", 1234, 1000, caba, 5, 2);
        Domicilio domicilioLaPlata = new Domicilio(2L, "Calle 12", 456, 1900, laPlata, 3, 1);
        Domicilio domicilioCordobaCapital = new Domicilio(3L, "Av. Colón", 789, 5000, cordobaCapital, 1, 0);
        Domicilio domicilioCarlosPaz = new Domicilio(4L, "San Martín", 321, 5152, carlosPaz, 2, 3);

        // Sucursales
        Sucursal sucursal1 = Sucursal.builder()
                .id(1L)
                .nombre("Clases.Sucursal CABA")
                .domicilio(domicilioCaba)
                .horarioApertura(LocalTime.of(9, 0))
                .horarioCierre(LocalTime.of(18, 0))
                .esCasaMatriz(true)
                .build();

        Sucursal sucursal2 = Sucursal.builder()
                .id(2L)
                .nombre("Clases.Sucursal La Plata")
                .domicilio(domicilioLaPlata)
                .horarioApertura(LocalTime.of(9, 0))
                .horarioCierre(LocalTime.of(17, 0))
                .esCasaMatriz(false)
                .build();

        Sucursal sucursal3 = Sucursal.builder()
                .id(3L)
                .nombre("Clases.Sucursal Córdoba Capital")
                .domicilio(domicilioCordobaCapital)
                .horarioApertura(LocalTime.of(8, 30))
                .horarioCierre(LocalTime.of(17, 30))
                .esCasaMatriz(true)
                .build();

        Sucursal sucursal4 = Sucursal.builder()
                .id(4L)
                .nombre("Clases.Sucursal Carlos Paz")
                .domicilio(domicilioCarlosPaz)
                .horarioApertura(LocalTime.of(10, 0))
                .horarioCierre(LocalTime.of(18, 0))
                .esCasaMatriz(false)
                .build();

        // Empresas
        Empresa empresa1 = Empresa.builder()
                .nombre("Clases.Empresa Uno")
                .razonSocial("Clases.Empresa Uno S.A.")
                .cuit(30500123)
                .cuil(20305001234L)
                .logo("logo1.png")
                .build();
        empresa1.agregarSucursal(sucursal1);
        empresa1.agregarSucursal(sucursal2);

        Empresa empresa2 = Empresa.builder()
                .nombre("Clases.Empresa Dos")
                .razonSocial("Clases.Empresa Dos S.A.")
                .cuit(30600234)
                .cuil(20306002345L)
                .logo("logo2.png")
                .build();
        empresa2.agregarSucursal(sucursal3);
        empresa2.agregarSucursal(sucursal4);

        // Guardar empresas en el repositorio
        empresaRepo.save(empresa1);
        empresaRepo.save(empresa2);

        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
        // a) Mostrar todas las empresas
        System.out.println("Todas las empresas:");
        empresaRepo.findAll().forEach(System.out::println);
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
        // b) Buscar empresa por ID
        System.out.println("\nBuscar empresa por ID:");
        Empresa buscadaPorId = empresaRepo.findById(empresa1.getId()).orElse(null);
        System.out.println(buscadaPorId);
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
        // c) Buscar empresa por nombre
        System.out.println("\nBuscar empresa por nombre:");
        List<Empresa> buscadasPorNombre = empresaRepo.genericFindByField("nombre", "Clases.Empresa Dos");
        buscadasPorNombre.forEach(System.out::println);
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
        // d) Actualizar CUIL de Clases.Empresa Uno
        System.out.println("\nActualizar CUIL:");
        empresa1.setCuil(20999999999L);
        empresaRepo.genericUpdate(empresa1.getId(), empresa1);
        System.out.println(empresaRepo.findById(empresa1.getId()).orElse(null));
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
        // e) Eliminar Clases.Empresa Dos
        System.out.println("\nEliminar Clases.Empresa Dos:");
        empresaRepo.genericDelete(empresa2.getId());
        empresaRepo.findAll().forEach(System.out::println);
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
    }
}