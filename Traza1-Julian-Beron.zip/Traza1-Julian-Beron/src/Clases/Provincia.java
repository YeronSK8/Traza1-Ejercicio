package Clases;

import lombok.*;
import lombok.experimental.SuperBuilder;
import java.util.*;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)  // Con esto evitamos duplicados
@SuperBuilder
public class Provincia {
    @EqualsAndHashCode.Include
    private Long id;
    private String nombre;
    private Pais pais;

    @Builder.Default
    private Set<Localidad> localidades = new HashSet<>();

    @Override
    public String toString() {
        return "Clases.Provincia{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", pais=" + (pais != null ? pais.getNombre() : null) +
                '}';
    }
}