package Clases;

import lombok.*;

@Getter
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)  // Con esto evitamos duplicados
public class Domicilio {
    @EqualsAndHashCode.Include
    private Long id;
    private String calle;
    private Integer numero;
    private Integer cp;
    private Localidad localidad;
    private Integer piso;
    private Integer nroDpto;

    @Override
    public String toString() {
        return "Clases.Domicilio{" +
                "id=" + id +
                ", calle='" + calle + '\'' +
                ", numero=" + numero +
                ", cp=" + cp +
                ", piso=" + piso +
                ", nroDpto=" + nroDpto +
                ", localidad=" + (localidad != null ? localidad.getNombre() : null) +
                '}';
    }
}