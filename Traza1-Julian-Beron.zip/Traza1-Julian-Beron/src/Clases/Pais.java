package Clases;

import lombok.*;
import lombok.experimental.SuperBuilder;
import java.util.*;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)  // Con esto evitamos duplicados
@SuperBuilder
public class Pais {
    @EqualsAndHashCode.Include
    private Long id;
    private String nombre;

    @Builder.Default
    private Set<Provincia> provincias = new HashSet<>();

    @Override
    public String toString() {
        return "Clases.Pais{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                '}';
    }
}