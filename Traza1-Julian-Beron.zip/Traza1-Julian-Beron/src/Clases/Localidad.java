package Clases;

import lombok.*;
import java.util.*;

@Getter
@AllArgsConstructor
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)  // Con esto evitamos duplicados
public class Localidad {
    @EqualsAndHashCode.Include
    private Long id;
    private String nombre;
    private Provincia provincia;

    @Builder.Default
    private Set<Domicilio> domicilios = new HashSet<>();

    @Override
    public String toString() {
        return "Clases.Localidad{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", provincia=" + (provincia != null ? provincia.getNombre() : null) +
                '}';
    }
}